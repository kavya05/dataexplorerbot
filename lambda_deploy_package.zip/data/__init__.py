# -*- coding: utf-8 -*-
# File required for setuptools can only find data in packages
