#config file containing credentials for rds mysql instance
db_username = "master"
db_password = "zOMHavNCBtzJXcp"
db_name = "databot" 